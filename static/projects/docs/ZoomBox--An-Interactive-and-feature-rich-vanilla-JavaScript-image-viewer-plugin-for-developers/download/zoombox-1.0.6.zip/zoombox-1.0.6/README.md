# zoombox
It is an Interactive JavaScript image viewer with up to 10 customization option. Just add 'zoombox' attribute in img tag to let the action begin !

1. Link zoombox.min.css form dest/css to the <head> of the page.
2. Addzoombox.min.js file from dest/js before the closing </body> tag.
4. Copy images from dest/images folder and put then in the 'images' folder of your root directory.
3. Add "zoombox" attribute to the <img> tag.

# Full Documention over here !!
https://www.worldsofashishpatel.com/zoombox
